import logo from './logo.svg';
import './App.css';
import Form from './Pages/Form';
import React from 'react';
import Registration from './Pages/Registration';

function App() {
  return (
    <div className="App">
      <header className="App-header">
       {/* <Form/> */}
       <Registration/>
      </header>
    </div>
  );
}

export default App;


